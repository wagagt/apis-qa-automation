@echo off
REM Run the TestRail sync Python script using the venv python
setlocal

set "BASE=%USERPROFILE%\workspace\testrail_sync"
set "PYTHON=%BASE%\python_scripts\.venv\Scripts\python.exe"
set "SCRIPT=%BASE%\python_scripts\sync_newman_to_testrail.py"
set "COLLECTION=%BASE%\newman\BPXAPI.postman_collection.json"
set "CONFIG=%BASE%\config.json"

if not exist "%PYTHON%" (
  echo ERROR: venv python not found at %PYTHON%
  exit /b 1
)

"%PYTHON%" "%SCRIPT%" --collection "%COLLECTION%" --config "%CONFIG%" %*
endlocal
