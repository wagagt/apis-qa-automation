# Wrappers: run_sync & run_newman (BAT + Python launchers)

Contenido:
- `run_sync.bat` : llama al script `sync_newman_to_testrail.py` usando el python del `.venv` (no requiere activar).
- `run_newman.bat`: ejecuta `newman.cmd` con la colección y environment por defecto.
- `launcher_newman.py`: lanzador opcional en Python para ejecutar Newman.
- `launcher_sync.py`: lanzador opcional en Python para ejecutar el sync usando el venv python.

Rutas usadas (personaliza si hace falta):
- Proyecto: `%USERPROFILE%\workspace\testrail_sync`
- Scripts Python: `%USERPROFILE%\workspace\testrail_sync\python_scripts\sync_newman_to_testrail.py`
- venv: `%USERPROFILE%\workspace\testrail_sync\python_scripts\.venv`
- Newman: `%USERPROFILE%\tools\node\newman.cmd`
- Collections: `%USERPROFILE%\workspace\testrail_sync\newman\BPXAPI.postman_collection.json`
- Config: `%USERPROFILE%\workspace\testrail_sync\config.json`

## Instalación rápida (pasos)
1. Coloca los archivos `.bat` en `%USERPROFILE%\bin` (ese folder ya está en tu PATH en sesiones anteriores).
   - Ejemplo desde PowerShell:
     ```powershell
     mkdir -Force $env:USERPROFILE\bin
     copy .\run_sync.bat $env:USERPROFILE\bin\
     copy .\run_newman.bat $env:USERPROFILE\bin\
     ```
2. Coloca los `.py` en tu carpeta de scripts Python:
   - Ejemplo:
     ```powershell
     mkdir -Force "$env:USERPROFILE\workspace\testrail_sync\python_scripts"
     copy .\launcher_sync.py "$env:USERPROFILE\workspace\testrail_sync\python_scripts\"
     copy .\launcher_newman.py "$env:USERPROFILE\workspace\testrail_sync\python_scripts\"
     ```
3. Asegúrate de que:
   - Existe el venv en `...python_scripts\.venv` con `pip` instalado.
   - La colección y environment están en `...\newman\`
   - `config.json` existe en `...` (contiene credenciales y project_id).
   - `newman.cmd` existe en `%USERPROFILE%\tools\node\newman.cmd`.

## Uso (ejemplos)
- Ejecutar sync (dry-run):
  ```
  run_sync.bat --dry-run
  ```
- Ejecutar Newman (CLI):
  ```
  run_newman.bat --reporters cli,json --reporter-json-export result.json
  ```
- Ejecutar launcher Python (opcional):
  ```
  python "%USERPROFILE%\workspace\testrail_sync\python_scripts\launcher_sync.py" --dry-run
  python "%USERPROFILE%\workspace\testrail_sync\python_scripts\launcher_newman.py" --reporters cli
  ```

## Notas y recomendaciones
- Los `.bat` llaman directamente al `python.exe` dentro del `.venv`, por eso no necesitas activar el virtualenv en la sesión.
- Mantén `config.json` fuera del control de versiones (contiene credenciales).
- Ajusta las rutas al inicio de los scripts si tu estructura cambia.
- Si usas PowerShell, los `.bat` funcionan desde la terminal sin problema.
