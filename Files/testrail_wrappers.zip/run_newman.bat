@echo off
setlocal

set "BASE=%USERPROFILE%\workspace\testrail_sync"
set "NEWMAN=%USERPROFILE%\tools\node\newman.cmd"
set "COLLECTION=%BASE%\newman\BPXAPI.postman_collection.json"
set "ENV=%BASE%\newman\BPXAPI.postman_environment.json"

if not exist "%NEWMAN%" (
  echo ERROR: newman not found at %NEWMAN%
  exit /b 1
)

"%NEWMAN%" run "%COLLECTION%" -e "%ENV%" %*
endlocal
